/**
 * Created by Yasir on 8/23/2016.
 */
(function () {
    "use strict";

    angular
        .module("productManagement")
        .controller("ProductDetailCtrl",["product",

                ProductDetailCtrl]);

    function ProductDetailCtrl(product){
        var vm = this;

        vm.product = product;

        vm.title = "Product Detail: " + vm.product.productName;


       // vm.marginPercent =
          //  productService.calculateMarginPercent(vm.product.price, vm.product.cost);

        if (vm.product.tags) {
            vm.product.tagList = vm.product.tags.toString();
        }
    }
}());
