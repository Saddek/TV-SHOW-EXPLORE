/**
 * Created by Yasir on 8/22/2016.
 */
(function () {

    "use strict";
    var app = angular.module("productResourceMock",["ngMockE2E"]);

    app.run(function ($httpBackend) {
        var products = [
            {
                "productId": 1,
                "productName": "Minimum Viable Product ",
                "productCode": "GDN-0011",
                "releaseDate": "April 6, 2014",
                "description": "Richard is a computer programmer. He has to choose between a $10 million deal with Gavin Belson and a $200.000 deal with Peter Gregory, in exchange for his cooperation to make the idea of a super compressing algorithm change the world.",
                "cost": 9.00,
                "price": 19.95,
                "category": "Silicon Valley",
                "tags": ["leaf", "Silicon Valley"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BYWIyODUxOTItOTYwNS00Mjc4LWI4ZjUtNWQ2YWVmNWQ1MmViXkEyXkFqcGdeQXVyMjg2MTMyNTM@._V1_.jpg"
            },
            {
                "productId": 2,
                "productName": "The Cap Table",
                "productCode": "GDN-0023",
                "releaseDate": "13 Apr. 2014",
                "description": "Richard hires Jared to design a business plan. Big Head is asked to work for Gavin Belson, where he discovers that Hooli has stolen the Pied Piper algorithm and calls it Nucleus. Meanwhile Richard struggles to get his money from Gregory.",
                "cost": 20.00,
                "price": 32.99,
                "category": "Silicon Valley ",
                "tags": ["barrow", "Silicon Valley", "wheelbarrow"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMTk2MDg2NjMzM15BMl5BanBnXkFtZTgwMzk0NTc5MjE@._V1_.jpg"
            },
            {
                "productId": 5,
                "productName": "Fiduciary Duties",
                "productCode": "TBX-0048",
                "releaseDate": "27 Apr. 2014",
                "description": "Richard drunkenly promises to make Erlich a board member, which he regrets the next morning. Big Head finds others at Hooli, who like him, have made careers out of doing nothing. Richard struggles to put Pied Piper's vision into words",
                "cost": 1.00,
                "price": 8.99,
                "category": "Silicon Valley ",
                "tags": ["Silicon Valley"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMjI4NTM2NzY3N15BMl5BanBnXkFtZTgwODk2NTc5MjE@._V1_.jpg"
            },
            {
                "productId": 8,
                "productName": "Signaling Risk",
                "productCode": "TBX-0022",
                "releaseDate": "May 4, 2014",
                "description": "Now that Pied Piper is the official company name, Erlich wants a logotype to go with it so he hires a very unexpected artist in for the job. Meanwhile Richard gets a tighter deadline for the project after a simple mistake.",
                "cost": 6.95,
                "price": 11.55,
                "category": "Silicon Valley",
                "tags": ["Silicon Valley", "mower"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMTYwNDgyMzI5NV5BMl5BanBnXkFtZTgwMTc1NDc5MjE@._V1_UX200_CR0,0,200,112_AL_.jpg"
            },
            {
                "productId": 10,
                "productName": "The Red Woman",
                "productCode": "GMG-0042",
                "releaseDate": "April 24, 2016",
                "description": "The fate of Jon Snow is revealed. Daenerys is brought before Khal Moro. Tyrion gets used to living in Meereen. Ramsay sends his dogs after Theon and Sansa. Ellaria and the Sand Snakes make their move. Cersei mourns for Myrcella.",
                "cost": 2.22,
                "price": 35.95,
                "category": "Game of Thrones ",
                "tags": ["gaming", "Game of Thrones", "video game"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMjExOTYxMDM0N15BMl5BanBnXkFtZTgwNjY5Njk5NzE@._V1_UX200_CR0,0,200,112_AL_.jpg"
            }
            ,
            {
                "productId": 13,
                "productName": "Book of the Stranger",
                "productCode": "GMG-0042",
                "releaseDate": "15 May 2016",
                "description": "Sansa arrives at Castle Black. Tyrion makes a deal with the Slave Masters. Jorah and Daario sneak into Vaes Dothrak. Ramsay sends a letter to Jon. Theon arrives at Pyke. Cersei and Olenna Tyrell plot against the High Sparrow.",
                "cost": 2.22,
                "price": 35.95,
                "category": "Game of Thrones ",
                "tags": ["gaming", "Game of Thrones", "video game"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMjQwNDc1NjkyOV5BMl5BanBnXkFtZTgwNDkwMzg4ODE@._V1_SY1000_CR0,0,1502,1000_AL_.jpg"
            }
            ,
            {
                "productId": 12,
                "productName": "Blood of My Blood",
                "productCode": "GMG-0042",
                "releaseDate": "29 May 2016",
                "description": "Bran and Meera find a new ally. Gilly meets Sam's family. Arya makes a difficult choice. The Lannisters and Tyrells march against the High Sparrow.",
                "cost": 2.22,
                "price": 35.95,
                "category": "Game of Thrones ",
                "tags": ["gaming", "Game of Thrones", "video game"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BNjA2NTgwOTUwN15BMl5BanBnXkFtZTgwMzMyNzYwOTE@._V1_UX200_CR0,0,200,112_AL_.jpg"
            }
            ,
            {
                "productId": 11,
                "productName": "The Broken Man",
                "productCode": "GMG-0042",
                "releaseDate": "5 Jun. 2016 ",
                "description": "Jon and Sansa gather troops. Jaime arrives at Riverrun. Olenna Tyrell plans to leave King's Landing. Theon and Yara plan a destination. Arya makes plans to leave.",
                "cost": 2.22,
                "price": 35.95,
                "category": "Game of Thrones ",
                "tags": ["gaming", "Game of Thrones", "video game"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMjI4OTAxMDQ1NF5BMl5BanBnXkFtZTgwNTgyNzYwOTE@._V1_SY1000_CR0,0,1502,1000_AL_.jpg"
            }
            ,
            {
                "productId": 14,
                "productName": "Battle of the Bastards",
                "productCode": "GMG-0042",
                "releaseDate": "19 Jun. 2016",
                "description": "Jon and Sansa face Ramsay Bolton on the fields of Winterfell. Daenerys strikes back at her enemies. Theon and Yara arrive in Meereen.",
                "cost": 2.22,
                "price": 35.95,
                "category": "Game of Thrones ",
                "tags": ["gaming", "Game of Thrones", "video game"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMjMyMDg3NDA1MF5BMl5BanBnXkFtZTgwNTA3MTE2OTE@._V1_UX200_CR0,0,200,112_AL_.jpg"
            }
            ,
            {
                "productId": 15,
                "productName": "Live Free or Die",
                "productCode": "GMG-0042",
                "releaseDate": "15 Jul. 2012",
                "description": "Now that Gus is dead, Walt, Jesse, and Mike work to cover their tracks. Skyler panics when Ted Beneke wakes up.",
                "cost": 2.22,
                "price": 35.95,
                "category": "Breaking Bad ",
                "tags": ["gaming", "Breaking Bad", "video game"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMjIwMzc0Mjk2N15BMl5BanBnXkFtZTcwODM5NzY5Nw@@._V1_UX200_CR0,0,200,112_AL_.jpg"
            }
            ,{
                "productId": 16,
                "productName": "Hazard Pay",
                "productCode": "GMG-0042",
                "releaseDate": "29 Jul. 2012 ",
                "description": "The guys put a business plan into action; Walt confesses to Marie.",
                "cost": 2.22,
                "price": 35.95,
                "category": "Breaking Bad ",
                "tags": ["gaming", "Breaking Bad", "video game"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BNzE0MzM0ODc3NV5BMl5BanBnXkFtZTgwMzcyNzc5MjE@._V1_UX200_CR0,0,200,112_AL_.jpg"
            }
            ,{
                "productId": 17,
                "productName": "Say My Name",
                "productCode": "GMG-0042",
                "releaseDate": "26 Aug. 2012",
                "description": "Mike and Jesse are out. Now Walt has to handle things on his own. Hank finally finds a rat in Mike's gang.",
                "cost": 2.22,
                "price": 35.95,
                "category": "Breaking Bad ",
                "tags": ["gaming", "Breaking Bad", "video game"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMTM1MjcyMzIzMl5BMl5BanBnXkFtZTcwOTk4MzAzOA@@._V1_UX200_CR0,0,200,112_AL_.jpg"
            }
            ,
            {
                "productId": 18,
                "productName": "To'hajiilee ",
                "productCode": "GMG-0042",
                "releaseDate": "8 Sep. 2013 ",
                "description": "Jesse and Hank come up with an idea to take Walt down. Walt hires Todd's uncle to kill Jesse.",
                "cost": 2.22,
                "price": 35.95,
                "category": "Breaking Bad ",
                "tags": ["gaming", "Breaking Bad", "video game"],
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMTQxODA3NTE1N15BMl5BanBnXkFtZTgwMTEyMjEyMDE@._V1_UX200_CR0,0,200,112_AL_.jpg"
            }
        ];

        var productUrl = "/api/products"

        $httpBackend.whenGET(productUrl).respond(products);

        var editingRegex = new RegExp(productUrl + "/[0-9][0-9]*", '');
        $httpBackend.whenGET(editingRegex).respond(function (method, url, data) {
            var product = {"productId": 0};
            var parameters = url.split('/');
            var length = parameters.length;
            var id = parameters[length - 1];

            if (id > 0) {
                for (var i = 0; i < products.length; i++) {
                    if (products[i].productId == id) {
                        product = products[i];
                        break;
                    }
                };
            }
            return [200, product, {}];
        });

        $httpBackend.whenPOST(productUrl).respond(function (method, url, data) {
            var product = angular.fromJson(data);

            if (!product.productId) {
                // new product Id
                product.productId = products[products.length - 1].productId + 1;
                products.push(product);
            }
            else {
                // Updated product
                for (var i = 0; i < products.length; i++) {
                    if (products[i].productId == product.productId) {
                        products[i] = product;
                        break;
                    }
                };
            }
            return [200, product, {}];
        });

        // Pass through any requests for application files
        $httpBackend.whenGET(/app/).passThrough();

    })

}());